//
// Created by nuray on 1.5.22.
//
#include <memory>
#include "Menu.hpp"





int main() {

    Menu menu;
    menu.welcome();
    menu.MainMenu();



    return 0;

    }



